<template>
  <div>
    <MSwitchRow v-if="tlsOptional" v-model="tlsEnable" :label="$t('objects.tls')" :desc="$t('tls.enable')" />
    <div v-if="tls.enabled" class="fade-up">
      <div style="display: flex; align-items: center; gap: 24px; flex-wrap: wrap; margin-bottom: 15px;">
        <SwitchLabel v-model="disable_sni" :label="$t('tls.disableSni')" />
        <SwitchLabel v-model="insecure" :label="$t('tls.insecure')" />
        <span style="flex: 1;"></span>
        <Pop :min-width="230">
          <template #trigger="{ toggle }">
            <Btn sm @click="toggle">
              <Ico name="settings" :size="14" /> {{ $t('tls.options') }}
            </Btn>
          </template>
          <div style="display: flex; flex-direction: column; gap: 2px; padding: 5px; max-height: 300px; overflow-y: auto;">
            <SwitchLabel v-model="optionCert" :label="$t('tls.cert')" />
            <SwitchLabel v-model="optionSNI" label="SNI" />
            <SwitchLabel v-model="optionALPN" label="ALPN" />
            <SwitchLabel v-model="optionMinV" :label="$t('tls.minVer')" />
            <SwitchLabel v-model="optionMaxV" :label="$t('tls.maxVer')" />
            <SwitchLabel v-model="optionCS" :label="$t('tls.cs')" />
            <SwitchLabel v-model="optionFP" label="UTLS" />
            <SwitchLabel v-model="optionReality" label="Reality" />
            <SwitchLabel v-model="optionEch" label="ECH" />
            <SwitchLabel v-model="optionFragment" :label="$t('tls.fragment')" />
          </div>
        </Pop>
      </div>
      <template v-if="optionCert">
        <!-- Path mode was removed: a path is only meaningful on the panel
             host and leaks into subscriptions as a broken client config. -->
        <Field :label="$t('tls.cert')">
          <textarea class="input mono" rows="4" v-model="tls.certificate"></textarea>
        </Field>
      </template>
      <Field v-if="tls.server_name != undefined" label="SNI">
        <input class="input mono" v-model="tls.server_name" />
      </Field>
      <Field v-if="tls.alpn" label="ALPN">
        <MultiPick v-model="tls.alpn" :options="ALPN_OPTIONS" />
      </Field>
      <div class="grid2">
        <Field v-if="tls.min_version" :label="$t('tls.minVer')">
          <Select v-model="tls.min_version">
            <option v-for="ver in TLS_VERSIONS" :key="ver" :value="ver">{{ ver }}</option>
          </Select>
        </Field>
        <Field v-if="tls.max_version" :label="$t('tls.maxVer')">
          <Select v-model="tls.max_version">
            <option v-for="ver in TLS_VERSIONS" :key="ver" :value="ver">{{ ver }}</option>
          </Select>
        </Field>
      </div>
      <ChipSelect
        v-if="tls.cipher_suites != undefined"
        v-model="tls.cipher_suites"
        :options="CIPHER_SUITES"
        :label="$t('tls.cs')"
        style="margin-bottom: 15px;"
      />
      <Field v-if="tls.utls != undefined" label="Fingerprint">
        <Select v-model="tls.utls.fingerprint">
          <option v-for="f in UTLS_FINGERPRINTS" :key="f.value" :value="f.value">{{ f.title }}</option>
        </Select>
      </Field>
      <div v-if="tls.reality != undefined" class="grid2">
        <Field :label="$t('tls.pubKey')">
          <input class="input mono" v-model="tls.reality.public_key" />
        </Field>
        <Field label="Short ID">
          <input class="input mono" v-model="tls.reality.short_id" />
        </Field>
      </div>
      <template v-if="tls.ech != undefined">
        <SectionLabel style="margin-bottom: 10px;">ECH</SectionLabel>
        <Segmented
          v-model="useEchPath"
          :options="[[0, $t('tls.usePath')], [1, $t('tls.useText')]]"
          style="margin-bottom: 12px;"
          @update:model-value="onEchMode"
        />
        <Field v-if="useEchPath == 0" :label="$t('tls.certPath')">
          <input class="input mono" v-model="tls.ech.config_path" />
        </Field>
        <Field v-else :label="$t('tls.cert')">
          <textarea class="input mono" rows="4" v-model="echConfigText"></textarea>
        </Field>
        <Field :label="$t('tls.queryServerName')">
          <input class="input mono" v-model="tls.ech.query_server_name" placeholder="ech.example.com" />
        </Field>
      </template>
      <template v-if="tls.fragment != undefined">
        <div style="display: flex; gap: 24px; flex-wrap: wrap; margin-bottom: 15px;">
          <SwitchLabel v-model="tls.fragment" :label="$t('tls.fragment')" />
          <SwitchLabel v-if="tls.fragment" v-model="tls.record_fragment" :label="$t('tls.recordFragment')" />
        </div>
        <Field v-if="tls.fragment" :label="$t('tls.fragmentDelay') + ' (' + $t('date.ms') + ')'">
          <input class="input mono" type="number" min="0" v-model.number="fragmentFallbackDelay" />
        </Field>
      </template>
    </div>
  </div>
</template>

<script lang="ts" setup>
import Select from '@/components/ui/Select.vue'
import { computed, ref } from 'vue'
import { defaultOutTls, ALPN_OPTIONS, TLS_VERSIONS, CIPHER_SUITES, UTLS_FINGERPRINTS } from '@/types/tls'
import Field from '@/components/ui/Field.vue'
import SectionLabel from '@/components/ui/SectionLabel.vue'
import SwitchLabel from '@/components/ui/SwitchLabel.vue'
import MSwitchRow from '@/components/ui/MSwitchRow.vue'
import Segmented from '@/components/ui/Segmented.vue'
import MultiPick from '@/components/ui/MultiPick.vue'
import ChipSelect from '@/components/ui/ChipSelect.vue'
import Pop from '@/components/ui/Pop.vue'
import Ico from '@/components/ui/Ico.vue'
import Btn from '@/components/ui/Btn.vue'

const props = defineProps<{ outbound: any }>()

const useEchPath = ref<string | number>(props.outbound?.tls?.ech?.config ? 1 : 0)



const tls = computed<any>(() => props.outbound.tls)

const tlsEnable = computed({
  get: (): boolean => (Object.hasOwn(tls.value, 'enabled') ? tls.value.enabled : false),
  set: (v: boolean) => { props.outbound.tls = v ? { enabled: true } : { enabled: false } },
})

const disable_sni = computed({
  get: (): boolean => tls.value.disable_sni ?? false,
  set: (v: boolean) => { props.outbound.tls.disable_sni = v ? true : undefined },
})

const insecure = computed({
  get: (): boolean => tls.value.insecure ?? false,
  set: (v: boolean) => { props.outbound.tls.insecure = v ? true : undefined },
})

const tlsOptional = computed((): boolean =>
  !['hysteria', 'hysteria2', 'tuic', 'shadowtls', 'anytls', 'naive'].includes(props.outbound.type)
)

const echConfigText = computed({
  get: (): string => (tls.value.ech?.config ? tls.value.ech.config.join('\n') : ''),
  set: (v: string) => { if (tls.value.ech) tls.value.ech.config = v.split('\n') },
})

const onEchMode = (v: string | number) => {
  if (v == 0) {
    delete tls.value.ech?.config
  } else {
    delete tls.value.ech?.config_path
  }
}

const optionCert = computed({
  get: (): boolean => tls.value.certificate != undefined || tls.value.certificate_path != undefined,
  set: (v: boolean) => {
    // Legacy rows may still carry a server-side path — drop it either way.
    delete props.outbound.tls.certificate_path
    if (v) {
      props.outbound.tls.certificate = ''
    } else {
      delete props.outbound.tls.certificate
    }
  },
})

const optionSNI = computed({
  get: (): boolean => tls.value.server_name != undefined,
  set: (v: boolean) => { props.outbound.tls.server_name = v ? '' : undefined },
})

const optionALPN = computed({
  get: (): boolean => tls.value.alpn != undefined,
  set: (v: boolean) => { props.outbound.tls.alpn = v ? defaultOutTls.alpn : undefined },
})

const optionMinV = computed({
  get: (): boolean => tls.value.min_version != undefined,
  set: (v: boolean) => { props.outbound.tls.min_version = v ? defaultOutTls.min_version : undefined },
})

const optionMaxV = computed({
  get: (): boolean => tls.value.max_version != undefined,
  set: (v: boolean) => { props.outbound.tls.max_version = v ? defaultOutTls.max_version : undefined },
})

const optionCS = computed({
  get: (): boolean => tls.value.cipher_suites != undefined,
  set: (v: boolean) => { props.outbound.tls.cipher_suites = v ? defaultOutTls.cipher_suites : undefined },
})

const optionFP = computed({
  get: (): boolean => tls.value.utls != undefined,
  set: (v: boolean) => { props.outbound.tls.utls = v ? defaultOutTls.utls : undefined },
})

const optionReality = computed({
  get: (): boolean => tls.value.reality != undefined,
  set: (v: boolean) => { props.outbound.tls.reality = v ? defaultOutTls.reality : undefined },
})

const optionEch = computed({
  get: (): boolean => tls.value.ech != undefined,
  set: (v: boolean) => { props.outbound.tls.ech = v ? defaultOutTls.ech : undefined },
})

const optionFragment = computed({
  get: (): boolean => tls.value.fragment != undefined,
  set: (v: boolean) => {
    if (v) {
      props.outbound.tls.fragment = false
    } else {
      delete props.outbound.tls.fragment
      delete props.outbound.tls.fragment_fallback_delay
      delete props.outbound.tls.record_fragment
    }
  },
})

const fragmentFallbackDelay = computed({
  get: (): number => parseInt(tls.value.fragment_fallback_delay?.replace('ms', '') ?? '500') ?? 500,
  set: (v: number) => { props.outbound.tls.fragment_fallback_delay = v > 0 ? `${v}ms` : undefined },
})
</script>
