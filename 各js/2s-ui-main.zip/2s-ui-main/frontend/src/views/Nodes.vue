<template>
  <NodeDrawer
    :visible="drawer.visible"
    :id="drawer.id"
    :data="drawer.data"
    @close="drawer.visible = false"
  />
  <NodeImportModal
    :visible="importModal.visible"
    :node-id="importModal.nodeId"
    :node-name="importModal.nodeName"
    @close="importModal.visible = false"
  />

  <!-- delete confirmation -->
  <DeleteConfirm :open="del.visible" :loading="deleting" @close="del.visible = false" @confirm="confirmDelete" />

  <div class="page-stack fade-up">
    <div class="toolbar" style="justify-content: center;">
      <Btn variant="primary" sm @click="openDrawer(0)">
        <Ico name="plus" :size="15" /> {{ $t('actions.add') }}
      </Btn>
    </div>

    <EmptyState v-if="nodes.length === 0" icon="server" :title="$t('node.emptyTitle')" :desc="$t('node.emptyDesc')" />

    <div v-else class="entity-grid">
      <EntityCard
        v-for="item in nodes"
        :key="item.id"
        :title="item.name"
        :type="displayUrl(item)"
        :color="stateColor(item)"
        icon="server"
        :rows="cardRows(item)"
      >
        <template #chip>
          <Chip v-if="item.dirty" color="amber" :title="$t('node.syncDirty')">{{ $t('node.syncDirty') }}</Chip>
          <Chip v-if="stateOf(item) === 'online'" color="emerald" dot>{{ $t('node.status.online') }}</Chip>
          <Chip v-else-if="stateOf(item) === 'core-stopped'" color="amber">{{ $t('node.status.coreStopped') }}</Chip>
          <Chip v-else-if="stateOf(item) === 'offline'" color="rose">{{ $t('node.status.offline') }}</Chip>
          <Chip v-else-if="stateOf(item) === 'disabled'">{{ $t('disable') }}</Chip>
          <Chip v-else>{{ $t('node.status.pending') }}</Chip>
        </template>
        <template #actions>
          <CardBtn icon="edit" :title="$t('actions.edit')" @click="openDrawer(item.id)" />
          <CardBtn icon="download" border :title="$t('node.import')" @click="openImport(item)" />
          <CardBtn
            icon="refresh"
            border
            :title="$t('node.reconcile')"
            :disabled="reconciling === item.id"
            @click="reconcile(item)"
          />
          <CardBtn icon="trash" border danger :title="$t('actions.del')" @click="askDelete(item.id)" />
        </template>
      </EntityCard>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import Data from '@/store/modules/data'
import { intlLocale } from '@/locales'
import { Node, NodeStatus } from '@/types/node'
import Btn from '@/components/ui/Btn.vue'
import Ico from '@/components/ui/Ico.vue'
import Chip from '@/components/ui/Chip.vue'
import DeleteConfirm from '@/components/ui/DeleteConfirm.vue'
import CardBtn from '@/components/ui/CardBtn.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import EntityCard, { EntityRow } from '@/components/ui/EntityCard.vue'
import NodeDrawer from '@/layouts/drawers/node/NodeDrawer.vue'
import NodeImportModal from '@/layouts/drawers/node/NodeImportModal.vue'
import HttpUtils from '@/plugins/httputil'

const { t } = useI18n({ useScope: 'global' })
const dataStore = Data()

const nodes = computed((): Node[] => <Node[]>dataStore.nodes)

// ---------------- live state ----------------
type CardState = 'online' | 'offline' | 'core-stopped' | 'disabled' | 'pending'

const statusOf = (n: Node): NodeStatus | undefined => dataStore.nodesStatus[n.id]

const stateOf = (n: Node): CardState => {
  if (!n.enable) return 'disabled'
  const st = statusOf(n)
  // No snapshot yet: heartbeat hasn't reached this node since panel start.
  if (!st) return 'pending'
  return st.state
}

const stateColor = (n: Node): string => {
  switch (stateOf(n)) {
    case 'online': return 'var(--emerald)'
    case 'core-stopped': return 'var(--amber)'
    case 'offline': return 'var(--rose)'
    default: return 'var(--text-3)'
  }
}

const displayUrl = (n: Node): string => n.baseUrl.replace(/^https?:\/\//, '')

// ---------------- relative time ----------------
const relTime = (unix: number): string => {
  if (!unix) return t('ui.none')
  // built per call so switching language re-formats; hoisting it would pin the
  // formatter to the language the page was opened in
  const rtf = new Intl.RelativeTimeFormat(intlLocale(), { numeric: 'auto' })
  const diff = unix - Math.floor(Date.now() / 1000)
  const abs = Math.abs(diff)
  if (abs < 60) return rtf.format(Math.trunc(diff), 'second')
  if (abs < 3600) return rtf.format(Math.trunc(diff / 60), 'minute')
  if (abs < 86400) return rtf.format(Math.trunc(diff / 3600), 'hour')
  return rtf.format(Math.trunc(diff / 86400), 'day')
}

// ---------------- card rows ----------------
const pct = (v: number): string => Math.round(v) + '%'

const cardRows = (n: Node): EntityRow[] => {
  const state = stateOf(n)
  const st = statusOf(n)
  // 待同步的节点把"上次同步"标黄,与卡片顶部的 dirty 徽章呼应
  const lastSync: EntityRow = n.dirty
    ? { k: t('node.lastSync'), v: relTime(n.lastSync ?? 0), color: 'var(--amber)' }
    : { k: t('node.lastSync'), v: relTime(n.lastSync ?? 0) }
  if (state === 'online' || state === 'core-stopped') {
    const memPct = st!.mem.total > 0 ? (st!.mem.current / st!.mem.total) * 100 : 0
    return [
      { k: t('node.latency'), v: st!.latency + ' ' + t('date.ms'), mono: true },
      { k: t('ui.cpu') + ' / ' + t('ui.memory'), v: pct(st!.cpu) + ' / ' + pct(memPct), mono: true },
      { k: t('node.panelVersion'), v: st!.appVersion || t('ui.none'), mono: !!st!.appVersion },
      state === 'online'
        ? { k: t('node.coreVersion'), v: st!.coreVersion || t('ui.none'), mono: !!st!.coreVersion }
        : { k: t('node.coreVersion'), v: t('node.status.coreStopped'), color: 'var(--amber)' },
      lastSync,
    ]
  }
  if (state === 'offline') {
    return [
      { k: t('node.lastSeen'), v: relTime(st?.lastOnline || n.lastSeen) },
      { k: t('node.error'), v: st?.error ?? t('ui.none'), color: 'var(--rose)' },
      { k: t('node.panelVersion'), v: t('ui.none') },
      { k: t('node.coreVersion'), v: t('ui.none') },
      lastSync,
    ]
  }
  // pending / disabled
  return [
    { k: t('node.latency'), v: t('ui.none') },
    { k: t('ui.cpu') + ' / ' + t('ui.memory'), v: t('ui.none') },
    { k: t('node.lastSeen'), v: relTime(n.lastSeen) },
    { k: t('node.coreVersion'), v: t('ui.none') },
    lastSync,
  ]
}

// ---------------- drawer ----------------
const drawer = ref({ visible: false, id: 0, data: '' })
const openDrawer = (id: number) => {
  drawer.value.id = id
  drawer.value.data = id == 0 ? '{}' : JSON.stringify(nodes.value.findLast((n) => n.id == id))
  drawer.value.visible = true
}

// ---------------- import inbounds ----------------
const importModal = ref({ visible: false, nodeId: 0, nodeName: '' })
const openImport = (n: Node) => {
  importModal.value = { visible: true, nodeId: n.id, nodeName: n.name }
}

// ---------------- reconcile ----------------
const reconciling = ref(0)
const reconcile = async (n: Node) => {
  reconciling.value = n.id
  const msg = await HttpUtils.post('api/reconcileNode', { id: n.id })
  reconciling.value = 0
  if (msg.success) {
    dataStore.loadData()
  }
}

// ---------------- delete (with confirm) ----------------
const del = ref({ visible: false, id: 0 })
const deleting = ref(false)
const askDelete = (id: number) => {
  del.value.id = id
  del.value.visible = true
}
const confirmDelete = async () => {
  deleting.value = true
  const success = await dataStore.save('nodes', 'del', del.value.id)
  deleting.value = false
  if (success) del.value.visible = false
}
</script>
