// ================== 配置 ==================
const API_BASE = 'https://jinguoduanju.me';
const TOKEN = 'zlZy0xsTLhDBPCrJ8tpzNazlrrkEBpoPcuIHCnjCwiU';
const NAV_ID = '2';          // 2=全部，可换 7/3/6/5
const SELF_ORIGIN = '';      // 留空则自动用请求域名；也可写死你的域名

const HEADERS = {
  'Accept': 'application/json',
  'Authorization': `Bearer ${TOKEN}`,
  'User-Agent': 'Mozilla/5.0 (Cloudflare Worker)',
};

// ================== 工具 ==================
async function api(path) {
  const r = await fetch(API_BASE + path, { headers: HEADERS });
  if (!r.ok) throw new Error(`API ${path} -> ${r.status}`);
  return r.json();
}

// ================== 路由 ==================
export default {
  async fetch(request) {
    const url = new URL(request.url);
    const path = url.pathname;
    const origin = SELF_ORIGIN || url.origin;

    try {
      // ---------- 1) 生成 M3U 列表 ----------
      if (path === '/live.m3u') {
        const dramas = await api(`/api/v1/dramas?sort=latest&navigationId=${NAV_ID}`);

        let out = '#EXTM3U\n';
        for (const d of dramas) {
          const logo = d.coverUrl ? `${API_BASE}${d.coverUrl}` : '';
          const group = (d.tags && d.tags[0]) || '短剧';
          const name = (d.title || `drama-${d.id}`).replace(/[\r\n,]/g, ' ');
          // 用 drama_id 作为频道标识，播放时再查详情拿第一集
          out += `#EXTINF:-1 tvg-id="${d.id}" tvg-logo="${logo}" group-title="${group}",${name}\n`;
          out += `${origin}/play/${d.id}\n`;
        }

        return new Response(out, {
          headers: {
            'Content-Type': 'application/vnd.apple.mpegurl; charset=utf-8',
            'Access-Control-Allow-Origin': '*',
            'Cache-Control': 'public, max-age=300',
          },
        });
      }

      // ---------- 2) 播放重定向 ----------
      const playMatch = path.match(/^\/play\/(\d+)$/);
      if (playMatch) {
        const dramaId = playMatch[1];
        const epParam = url.searchParams.get('ep'); // 可选：/play/972?ep=1

        // 拿详情，找目标集（默认第1集）
        const detail = await api(`/api/v1/dramas/${dramaId}`);
        const episodes = detail.episodes || [];
        if (!episodes.length) return new Response('No episodes', { status: 404 });

        let target;
        if (epParam) {
          target = episodes.find(e => String(e.number) === epParam) || episodes[0];
        } else {
          target = episodes[0];
        }

        // 拿真实播放地址
        const play = await api(`/api/v1/episodes/${target.id}/play`);
        if (!play.videoUrl) return new Response('No videoUrl', { status: 404 });

        return Response.redirect(play.videoUrl, 302);
      }

      // ---------- 3) 可选：多集模式 /playall/{dramaId} ----------
      const allMatch = path.match(/^\/playall\/(\d+)$/);
      if (allMatch) {
        const dramaId = allMatch[1];
        const detail = await api(`/api/v1/dramas/${dramaId}`);
        const episodes = detail.episodes || [];
        // 返回一个只有该剧所有集的播放列表（多集连播用）
        let out = '#EXTM3U\n';
        for (const e of episodes) {
          const name = `${detail.drama.title} - ${e.title}`.replace(/[\r\n,]/g, ' ');
          out += `#EXTINF:-1,${name}\n`;
          out += `${origin}/play/${dramaId}?ep=${e.number}\n`;
        }
        return new Response(out, {
          headers: {
            'Content-Type': 'application/vnd.apple.mpegurl; charset=utf-8',
            'Access-Control-Allow-Origin': '*',
          },
        });
      }

      // ---------- 4) 健康检查 ----------
      if (path === '/' || path === '/health') {
        return new Response('OK', { status: 200 });
      }

      return new Response('Not Found', { status: 404 });
    } catch (e) {
      return new Response(`Error: ${e.message}`, { status: 500 });
    }
  },
};